<?php
// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';

$gatewayModuleName = basename(__FILE__, '.php');

// Fetch gateway configuration parameters.
$gatewayParams = getGatewayVariables($gatewayModuleName);

// Die if module is not active.
if (!$gatewayParams['type']) {
    die("Module Not Activated");
}


    $invoiceId = $_POST['remark1'];




    $gatewayTxnID = $_COOKIE['gatewayTxnID'];
    $status=$_POST['status'];
    $orderid=$_POST['order_id'];
    $amount=$_POST['amount'];




    

    if ($status =="SUCCESS") {
        // Add payment to the invoice
        $transactionId = $orderid;
        $paymentAmount = $amount;
        $paymentFee = 0; // Assuming no payment fee
        addInvoicePayment(
            $invoiceId,
            $transactionId,
            $paymentAmount,
            $paymentFee,
            $gatewayModuleName
        );

        // Redirect the user to the success URL
        callback3DSecureRedirect($invoiceId, true);

        exit;
    } else {
        echo "Invalid response received<br>";
    }

?>
