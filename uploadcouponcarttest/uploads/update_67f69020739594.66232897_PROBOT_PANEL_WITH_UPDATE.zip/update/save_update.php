<?php
header('Content-Type: application/json');

session_start();
$secure_token = bin2hex(random_bytes(16)); // generate secure token
$_SESSION['install_token'] = $secure_token;

$data = json_decode(file_get_contents('php://input'), true);

$panel_id = urlencode($data['panel_id'] ?? '');
$filename = urlencode($data['filename'] ?? '');

if (!$panel_id || !$filename) {
    echo json_encode(['status' => 'error', 'message' => 'Missing panel_id or filename']);
    exit;
}

$url = "https://upload.couponcart.in/secure_download.php?panel_id=$panel_id&file=$filename";

// Detect customer's domain
$domain = $_SERVER['HTTP_HOST'];
$headers = [
    "X-Domain: $domain"
];

// Initialize cURL session
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); // 🟢 Add custom domain header

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    echo json_encode(['status' => 'error', 'message' => "cURL error: " . curl_error($ch)]);
    curl_close($ch);
    exit;
}

if ($http_code !== 200) {
    echo json_encode(['status' => 'error', 'message' => "Download failed. Server responded with: $http_code"]);
    curl_close($ch);
    exit;
}

// Save the file in BINARY mode to avoid corruption
$localPath = __DIR__ . "/updates/$filename";
$dir = dirname($localPath);
if (!is_dir($dir)) mkdir($dir, 0777, true);

$fp = fopen($localPath, 'wb'); // Open in binary mode
fwrite($fp, $response);
fclose($fp);

curl_close($ch);

echo json_encode([
    'status' => 'success',
    'message' => "Download success!",
    'file' => $localPath,
    'install_url' => "install_update.php?token=$secure_token&filename=$filename"
]);
?>