<?php

// Load CodeIgniter bootstrap
require_once dirname(__DIR__) . '/vendor/autoload.php';
require_once dirname(__DIR__) . '/app/Config/Paths.php';

$paths = new Config\Paths();
require_once rtrim($paths->systemDirectory, '\\/') . '/bootstrap.php';



// Load UserModel
$userModel = new \App\Models\UserModel();

// Get logged-in user
$user = $userModel->getUser();

// Validate admin access
if (!$user || $user->level != 1) {
    http_response_code(403);
    die("<h3 style='color:red;text-align:center;'>❌ Access denied. </h3>");
}

header("Content-Type: application/json");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Path to your version file
$versionFilePath = __DIR__ . '/../version.txt';

$currentVersion = '0.0.0';

if (file_exists($versionFilePath)) {
    $currentVersion = trim(file_get_contents($versionFilePath));
}

$domain = $_SERVER['HTTP_HOST']; // auto gets domain like gamercart.shop

$context = stream_context_create([
    "http" => [
        "method" => "GET",
        "header" => "X-Domain: $domain\r\n"
    ]
]);

$latestVersionData = file_get_contents('https://upload.couponcart.in/latest_version.php', false, $context);
$latestVersionJson = json_decode($latestVersionData, true);

if (!$latestVersionJson || !isset($latestVersionJson['version'])) {
    die(json_encode(['status' => 'error', 'message' => 'Failed to fetch latest version']));
}

$latestVersion = $latestVersionJson['version'];
$filename = $latestVersionJson['filename'];
$changelog = $latestVersionJson['changelog'];

// Compare versions
if (version_compare($currentVersion, $latestVersion, '>=')) {
    echo json_encode(['status' => 'up-to-date', 'message' => 'Already on the latest version']);
    exit;
}

// Return download details
echo json_encode([
    'status' => 'update_available',
    'latest_version' => $latestVersion,
    'filename' => $filename,
    'changelog' => $changelog,
    'current_version' => $currentVersion
]);
?>
