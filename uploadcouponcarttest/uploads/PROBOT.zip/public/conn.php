<?php

$servername = "localhost";
$dbname = "game_panel";
$username = "game_panel";
$password = "game_panel";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>