<?php
include('conn.php');

if (!isset($_GET['amount'])) {
    die("Invalid request.");
}

$amount = intval($_GET['amount']);
$userid = session()->userid;
$order_id = uniqid(); // Generate a unique order ID

    // Count the number of pending orders for this user
$count_stmt = $conn->prepare("SELECT COUNT(*) FROM payments WHERE user_id = ? AND status = 'PENDING'");
$count_stmt->bind_param("i", $userid);
$count_stmt->execute();
$count_stmt->bind_result($pending_order_count);
$count_stmt->fetch();
$count_stmt->close();


if ($pending_order_count >= 5) {
    // Show Swal confirmation popup
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
    document.addEventListener('DOMContentLoaded', function () {
        Swal.fire({
                title: 'Too Many Pending Orders!',
                text: 'You have more than 5 pending orders. Please complete or cancel them before creating a new one.',
                icon: 'error',
                confirmButtonText: 'Go to Dashboard'
            }).then(() => {
                window.location.href = 'https://gamercart.shop/public/dashboard'; // Redirect to dashboard
            });
    });
</script>";
    exit;
}


// Insert new payment record
    $stmt = $conn->prepare("INSERT INTO payments (order_id, user_id, amount, status, created_at) VALUES (?, ?, ?, ?, ?)");
    $status = "PENDING";
    $stmt->bind_param("sidss", $order_id, $userid, $amount, $status, $time);
    $stmt->execute();
    $stmt->close();


// Set the API endpoint URL
$api_url = 'https://couponcart.in/api/create-order';

// Define the payload data
$data = array(
    'customer_mobile' => '8145344963',
    'user_token' => '3ca1a4f03d3be47c8e12b58cf84f2e88',
    'amount' => $amount,
    'order_id' => $order_id,
    'redirect_url' => 'https://gamercart.shop/public/callback?order_id=' . $order_id,
    'remark1' => 'WalletTopup',
    'remark2' => $userid, // Store user ID for wallet update
);

// Initialize cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data)); // Encode the data as form-urlencoded

// Execute the cURL request
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'cURL error: ' . curl_error($ch);
} else {
    // Parse the JSON response
    $result = json_decode($response, true);

    // Check if the status is true or false
    if ($result && isset($result['status'])) {
        if ($result['status'] === true) {
            // Order was created successfully
            echo 'Order Created Successfully<br>';
            echo 'Order ID: ' . $result['result']['orderId'] . '<br>';
            echo 'Payment URL: ' . $result['result']['payment_url'];
          
         // Order was created successfully
            $paymentUrl = $result['result']['payment_url'];
            
         // Redirect user to the payment URL
            header("Location: $paymentUrl");

        } else {
            // Plan expired
            echo 'Status: ' . $result['status'] . '<br>';
            echo 'Message: ' . $result['message'];
        }
    } else {
        // Invalid response
        echo 'Invalid API response';
    }
}

// Close cURL session
curl_close($ch);
?>
