<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center pt-5">
    <div class="col-lg-4">
        <?= $this->include('Layout/msgStatus') ?>
        <div class="col-lg-12">
        
        <div class="shadow p-3 mb-5 bg-white rounded " style="background: white; max-width: 80rem;">
            <div class="card-body text-center">
                    <h2 class="fw-bold text-primary">Welcome Back</h2>
                    <p class="text-muted">Login to your account</p>
                </div>
            <div class="card-body">
                <?= form_open() ?>
                <div class="form-group mb-3">
                    <label for="username">Username</label>
                    <input type="text" class="form-control mt-2 rounded" name="username" id="username" aria-describedby="help-username" placeholder="Enter Your username" required minlength="4">
                    <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group mb-3">
                    <label for="password">Password</label>
                    <input type="password" class="form-control mt-2 rounded" name="password" id="password" aria-describedby="help-password" placeholder="Enter Your password" required minlength="6">
                    <?php if ($validation->hasError('password')) : ?>
                        <small id="help-password" class="form-text text-danger"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-check mb-3">
                    <label class="form-check-label" data-bs-toggle="tooltip" data-bs-placement="top" title="Keep session more than 30 minutes">
                        <input type="checkbox" class="form-check-input rounded" name="stay_log" id="stay_log" value="yes">
                        Stay login?
                    </label>
                </div>
                <div class="form-group mb-2 d-grid">
                        <button type="submit" class="btn btn-primary rounded-pill fw-semibold p-2 w-100"><i class="bi bi-box-arrow-in-right"></i> Log in</button>
                    </div>
                <?= form_close() ?>
            </div>
            </div>
         
            <p class="text-left text-dark after-card">
                <small style="font-size: 15px;">Don't have an account?<a href="<?= site_url('register') ?>" role="button">Create an Account</a>
                </small>
            </p>
    
    </div>
</div>

<?= $this->endSection() ?>