<?php

namespace App\Controllers;

use App\Models\CodeModel;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * Class BaseController
 *
 * BaseController provides a convenient place for loading components
 * and performing functions that are needed by all your controllers.
 * Extend this class in any new controllers:
 *     class Home extends BaseController
 *
 * For security be sure to declare any new methods as protected or private.
 */

class BaseController extends Controller
{
	/**
	 * Instance of the main Request object.
	 *
	 * @var IncomingRequest|CLIRequest
	 */
	protected $request;

	/**
	 * An array of helpers to be loaded automatically upon
	 * class instantiation. These helpers will be available
	 * to all other controllers that extend BaseController.
	 *
	 * @var array
	 */
	protected $helpers = ['nata', 'form', 'url', 'text', 'html', 'filesystem'];
  
	/**
	 * Constructor.
	 *
	 * @param RequestInterface  $request
	 * @param ResponseInterface $response
	 * @param LoggerInterface   $logger
	 */
	function getUserIP()
	{
        $clientIp  = @$_SERVER['HTTP_CLIENT_IP'];
        $forwardIp = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remoteIp  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($clientIp, FILTER_VALIDATE_IP))
        {
            $ipaddress = $clientIp;
        }
        elseif(filter_var($forwardIp, FILTER_VALIDATE_IP))
        {
            $ipaddress = $forwardIp;
        }
        else
        {
            $ipaddress = $remoteIp;
        }
        return $ipaddress;
    }
	public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
	{
		// Do Not Edit This Line
		parent::initController($request, $response, $logger);

		// Path to Handler
    $handlerPath = APPPATH . 'Config/Handler.php';

    // Auto-restore Handler.php if it's missing

        $handlerContent = <<<PHP
<?php
namespace Config;

class Handler {
    public static function getLicenseKey()
    {
        \$licensePath = dirname(__DIR__, 2) . '/license.key';
        if (!file_exists(\$licensePath)) {
            return null;
        }
        return trim(file_get_contents(\$licensePath));
    }

    public static function validateLicense()
    {
        \$license_key = self::getLicenseKey();
        if (!\$license_key) {
            die("License key not found.");
        }

        \$device_info = php_uname();
        \$secret_key = 'YOUR_SECRET_SALT'; // Must match your backend
        \$device_id = hash_hmac('sha256', \$device_info, \$secret_key);

        \$payload = json_encode([
            'license_key' => \$license_key,
            'device_id' => \$device_id
        ]);

        \$domain = \$_SERVER['HTTP_HOST'];
        \$headers = [
            'Content-Type: application/json',
            "X-Domain: \$domain"
        ];

        \$ch = curl_init('https://upload.couponcart.in/api/validate-license.php');
        curl_setopt(\$ch, CURLOPT_POST, true);
        curl_setopt(\$ch, CURLOPT_POSTFIELDS, \$payload);
        curl_setopt(\$ch, CURLOPT_HTTPHEADER, \$headers);
        curl_setopt(\$ch, CURLOPT_RETURNTRANSFER, true);

        \$response = curl_exec(\$ch);
        \$httpcode = curl_getinfo(\$ch, CURLINFO_HTTP_CODE);
        curl_close(\$ch);

        \$data = json_decode(\$response, true);

        if (\$httpcode === 200 && isset(\$data['success']) && \$data['success'] === true) {
            return true;
        }

        return false;
    }
}
PHP;
// Hash to verify original content
$expectedHash = hash('sha256', $handlerContent);

// Check if file is missing or changed
$restore = false;


if (!file_exists($handlerPath)) {
    $restore = true;

} else {
    $currentHash = hash_file('sha256', $handlerPath);
    if ($currentHash !== $expectedHash) {
        $restore = true;

    }
}

if ($restore) {
    file_put_contents($handlerPath, $handlerContent);
}

    // Require and validate
    require_once $handlerPath;

    if (!\Config\Handler::validateLicense()) {
    echo "<style>
            body { background: #f5f5f5; font-family: sans-serif; text-align: center; padding: 100px; }
            .box { background: white; display: inline-block; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
            h2 { color: red; }
        </style>
        <div class='box'>
            <h2>❌ License Validation Failed</h2>
            <p>Your license could not be verified. Please check your license key.</p>
        </div>";
        exit;
    }
  }
}
