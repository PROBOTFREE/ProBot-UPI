<?php
session_start();





$am = $_GET['am'];
$user= $_GET['user'];


$orderid=uniqid().time().rand(1111,9999);
$_SESSION['xxorderid']=$orderid;
$_SESSION['xxuser']=$user;

// Set the API endpoint URL
$api_url = 'https://khilaadixpro.shop/api/create-order';

// Define the payload data
$data = array(
    'customer_mobile' => '1234567890',
    'user_token' => '1ae0b12c53a3223c9ab631f71744bcea',
    'amount' => $am,
    'order_id' => $orderid,   //use unique order id
    'redirect_url' => 'https://1xbetcolour.com/trova/src/api/callback.php',
    'remark1' => $user,
    'remark2' => 'testremark2',
    'route' =>1,
);

// Initialize cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $api_url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data)); // Encode the data as form-urlencoded

// Execute the cURL request
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'cURL error: ' . curl_error($ch);
} else {
    // Parse the JSON response
    $result = json_decode($response, true);

    // Check if the status is true or false
    if ($result && isset($result['status'])) {
        if ($result['status'] === true) {
            // Order was created successfully
            
            
           // echo 'Payment URL: ' . $result['result']['payment_url'];
           
           header("Location: {$result['result']['payment_url']}");
    exit(); // Terminate script execution
            
            
            
        } else {
            // Plan expired
            echo 'Status: ' . $result['status'] . '<br>';
            echo 'Message: ' . $result['message'];
        }
    } else {
        // Invalid response
        echo 'Invalid API response';
    }
}

// Close cURL session
curl_close($ch);



  
  
  
  
  
  