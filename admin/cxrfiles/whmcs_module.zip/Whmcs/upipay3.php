<?php
function upipay3_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'UpiPay3 ',
        ),
        'apiKey' => array(
            'FriendlyName' => 'API Key',
            'Type' => 'text',
            'Size' => '25',
            'Default' => '',
            'Description' => 'Enter your API key here',
        ),
    );
}

function upipay3_link($params)
{
    $key = $params['apiKey'];
    $userToken = $key; // Using apiKey as the user token

    // Invoice Parameters
    $invoiceId = $params['invoiceid'];
    $description = $params['description'];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];

    // Client Parameters
    $phone = $params['clientdetails']['phonenumber'];

    // System Parameters
    $systemUrl = $params['systemurl'];
    $moduleName = $params['paymentmethod'];

    // Callback URL
    $webhookurl = $systemUrl . '/modules/gateways/callback/' . $moduleName . '.php';  //this is webhook url;
    $redirectURL = $systemUrl;

    // Create the payment link
    $orderID = uniqid().time().rand(1111111111,9999999999);
    
    // URL of the PHP page
$url = 'https://khilaadixpro.shop/api/create-order';

// Data to be sent in the POST request
$data = array(
    'customer_mobile' => '1234567890',
    'user_token' => $key,
    'amount' => $amount,
    'order_id' => $orderID,
    'redirect_url' => $redirectURL,
    'remark1' => $invoiceId,
    'remark2' => 'test2',
    'route' =>2,
);

// Initialize cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL session and store the response
$response = curl_exec($ch);


// Close cURL session
curl_close($ch);

// Decode the JSON response
$jsonResponse = json_decode($response, true);

// Check if decoding was successful
if ($jsonResponse !== null) {
    // Check if the response contains the expected keys
    if (isset($jsonResponse['result']['payment_url'])) {
        // Redirect the user to the payment URL
        // Store values in cookies
            setcookie('invoiceId', $invoiceId, time() + 3600); // Expires in 1 hour
            setcookie('gatewayTxnID', $orderID, time() + 3600); // Expires in 1 hour
        $paymentUrl = $jsonResponse['result']['payment_url'];
        header('Location: ' . $paymentUrl);
        exit;
    } else {
        echo 'Payment URL not found in the response.';
        // Handle the error appropriately, for example:
        // die('Payment URL not found in the response.');
    }
} else {
    echo 'Failed to decode JSON response.';
    // Handle the error appropriately, for example:
    // die('Failed to decode JSON response.');
}
    
    
    
    }

  
function upipay3_cancelSubscription($params)
{
    // Subscription Parameters
    $subscriptionIdToCancel = $params['subscriptionID'];

    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    // Perform API call to cancel the subscription and interpret the result
    // Add your code here to cancel the subscription using the $subscriptionIdToCancel

    // Return the response
    return array(
        'status' => 'success', // 'success' if successful, any other value for failure
        'rawdata' => $responseData, // Data to be recorded in the gateway log - can be a string or array
    );
}
?>