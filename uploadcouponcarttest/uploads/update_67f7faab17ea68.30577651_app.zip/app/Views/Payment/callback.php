<?php
include('conn.php');

if (!isset($_GET['order_id']) || !preg_match('/^[a-zA-Z0-9]+$/', $_GET['order_id'])) {
    die("<div class='alert alert-danger text-center'>Invalid request.</div>");
}

$order_id = $_GET['order_id'];

// API endpoint URL
$url = "https://couponcart.in/api/check-order-status";

// POST data
$postData = array(
    "user_token" => "3ca1a4f03d3be47c8e12b58cf84f2e88",
    "order_id" => $order_id,
);

// Initialize cURL session
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));

// Execute cURL session and get the response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo "<div class='alert alert-danger text-center'>cURL Error: " . curl_error($ch) . "</div>";
    exit;
}

// Close cURL session
curl_close($ch);

// Decode the JSON response
$responseData = json_decode($response, true);

// Validate API response structure
if (!isset($responseData["status"]) || !isset($responseData["result"]["txnStatus"])) {
    die("<div class='alert alert-danger text-center'>Invalid API response.</div>");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css"> <!-- Added Bootstrap Icons -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">
    <div class="container text-center">
        <div class="card p-4 shadow-lg border-0">
            <?php
            if ($responseData["status"] == 1 && $responseData["result"]["txnStatus"] == "SUCCESS") {
                $txnStatus = $responseData["result"]["txnStatus"];
                $order_id = $responseData["result"]["orderId"];
                $amount = $responseData["result"]["amount"];
                $date = $responseData["result"]["date"];
                
                $conn->begin_transaction();
                try {
                
                $stmt = $conn->prepare("SELECT user_id, status FROM payments WHERE order_id = ?");
                $stmt->bind_param("s", $order_id);
                $stmt->execute();
                $stmt->bind_result($user_id, $payment_status);
                $stmt->fetch();
                $stmt->close();
                
                if ($payment_status === "SUCCESS") {
                    echo "<div class='alert alert-warning'><i class='bi bi-exclamation-triangle-fill'></i> Transaction already processed. Redirecting...</div>";
                    header("refresh:3;url=/public/dashboard");
                    exit;
                }
                
                $stmt = $conn->prepare("SELECT saldo FROM users WHERE id_users = ?");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $stmt->bind_result($current_balance);
                $stmt->fetch();
                $stmt->close();
                
                $new_balance = $current_balance + $amount;
                
                if (!$user_id) {
                    die("<div class='alert alert-danger'>Error: User ID not found for order.</div>");
                }
                
                $stmt = $conn->prepare("UPDATE users SET saldo = ? WHERE id_users = ?");
                $stmt->bind_param("di", $new_balance, $user_id);
                $stmt->execute();
                $stmt->close();
                
                $stmt = $conn->prepare("UPDATE payments SET status = 'SUCCESS' WHERE order_id = ?");
                $stmt->bind_param("s", $order_id);
                $stmt->execute();
                $stmt->close();
                
                 // Commit transaction
                $conn->commit();
                
                echo "<div class='alert alert-success'><i class='bi bi-check-circle-fill'></i> Payment Successful! Wallet updated.</div>";
                echo "<script>setTimeout(function(){ window.location.href='/public/dashboard'; }, 3000);</script>";
                
                } catch (Exception $e) {
                    $conn->rollback();
                    echo "<div class='alert alert-danger'><i class='bi bi-x-circle-fill'></i> Transaction failed: " . $e->getMessage() . "</div>";
                }
            } else {
                $errorMessage = isset($responseData["message"]) ? $responseData["message"] : "Unknown error.";
                echo "<div class='alert alert-danger'><i class='bi bi-x-circle-fill'></i> API Error: $errorMessage</div>";
            }
            ?>
        </div>
    </div>
</body>
</html>
