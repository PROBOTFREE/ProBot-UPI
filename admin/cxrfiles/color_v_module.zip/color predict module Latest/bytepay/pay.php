<?php
session_start();
$userid=$_SESSION['frontuserid'];
$name = $_SESSION['name'];    //////////////
$mobile = $_SESSION['mobile'];     //////////
$email = $_SESSION['email'];     ////////////
$finalAmount = $_SESSION['finalamount'];   /////////

$acx=$_COOKIE['cxruser'];


$orderId = uniqid() . substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 8) . time(); // Unique order ID.

$redirecturl = "https://{$_SERVER['SERVER_NAME']}/myaccount.php";


// URL of the PHP page
$url = 'https://khilaadixpro.shop/api/create-order';

// Data to be sent in the POST request
$data = array(
    'customer_mobile' => '1234567890',
    'user_token' => '4b08d135be18fd929fcb254620d6acc5',
    'amount' => $finalAmount,
    'order_id' => $orderId,
    'redirect_url' => $redirecturl,
    'remark1' => $userid,
    'remark2' => 'test2',
    'route'=>2,
);

// Initialize cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL session and store the response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'cURL Error: ' . curl_error($ch);
}

// Close cURL session
curl_close($ch);


// Decode the JSON response
$jsonResponse = json_decode($response, true);

// Check if decoding was successful
if ($jsonResponse !== null) {
    // Redirect the user to the payment URL
    $paymentUrl = $jsonResponse['result']['payment_url'];
    header('Location: ' . $paymentUrl);
    exit;
    
} else {
    echo $response;
    exit;
}


?>
