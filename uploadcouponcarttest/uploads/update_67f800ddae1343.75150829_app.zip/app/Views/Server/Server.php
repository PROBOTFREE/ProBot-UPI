<?php
include('conn.php');
include('mail.php');

// for maintainece mode
$sql1 ="select * from onoff where id=1";
$result1 = mysqli_query($conn, $sql1);
$userDetails1 = mysqli_fetch_assoc($result1);

// for ftext and status
$sql2 ="select * from _ftext where id=1";
$result2 = mysqli_query($conn, $sql2);
$userDetails2 = mysqli_fetch_assoc($result2);

// for Features Status
$sql3 = "SELECT * FROM Feature WHERE id=1";
$result3 = mysqli_query($conn, $sql3);
$ModFeatureStatus = mysqli_fetch_assoc($result3);

?>

<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>
<div class="row">
   <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
</div>
<!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
<div class="row mt-4">
     <?php if($user->level != 2) : ?>
     <div class="col-lg-6">
       <div class="card shadow h-100 py-2">
            <div class="card-header text-center font-weight-bold text-dark">
                Sever Status</div>
            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="status_form" value="1">
                <div class="form-group mb-3">
                    <label for="status">Current Maintenance Mode : <font size="2" color ="#a39c9b"><?php echo $userDetails1['status']; ?></font></label>
                        <div class="input-group mb-3">
                            <label id="esp" class="hacks">
                                Maintenance Mode
                                <div class="switch">
                                    <input type="checkbox" name="radios" id="radio" value="on" <?php if ($userDetails1['status'] == "on"){?> checked="checked" <?php } ?>>
                                    <span class="slider round"/>
                                </div>
                            </label>
                        </div>
                        <label for="modname">Current message : <font size="2" color ="#a39c9b"><?php echo $userDetails1['myinput']; ?></font></label>
                      <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">Offline Msg</span>
                      </div>
                          <textarea class="form-control" placeholder="Server is under maintenance" name = "myInput" id="myInput" id="exampleFormControlTextarea1" rows="1"></textarea>
                    </div>
                    <?php if ($validation->hasError('modname')) : ?>
                        <small id="help-modname" class="text-danger"><?= $validation->getError('modname') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group my-2">
                    <button type="submit" class="btn btn-outline-primary rounded-pill">Update</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
    <div class="col-lg-6">
        <div class="card shadow h-10 py-2">
            <div class="card-header text-center font-weight-bold text-dark">
                Mod Name</div>
            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="modname_form" value="1">
                <div class="form-group mb-3">
                    <label for="modname">Current Mod Name: <font size="2" color ="#a39c9b"><?php echo $row['modname']; ?></font></label>
                    <input type="text" name="modname" id="modname" class="form-control mt-2" placeholder="𝐸𝑛𝑡𝑒𝑟 𝑌𝑜𝑟 𝑁𝑒𝑤 𝑀𝑜𝑑 𝑁𝑎𝑚𝑒" aria-describedby="help-modname" REQUIRED>
                    <?php if ($validation->hasError('modname')) : ?>
                        <small id="help-modname" class="text-danger"><?= $validation->getError('modname') ?></small>
                    <?php endif; ?>
                </div>
                <div class="form-group my-2">
                    <button type="submit" class="btn btn-outline-warning rounded-pill">Update</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>
    <!----><!----><!----><!----><!----><!----><!----><!---->
<div class="row mt-4">
    <div class="col-lg-6">
       <div class="card shadow h-100 py-2">
            <div class="card-header text-center font-weight-bold text-dark">
                Mod Feature
            </div>
                <div class="card-body">
                    <?= form_open() ?>
                    
                      <input type="hidden" name="feature_form" value="1">
                        <div class="form-group mb-3">
                            <label for="status">Current Status : ESP - <font color ="#a39c9b"><?php echo $ModFeatureStatus['ESP']; ?></font>  Items - <font color ="#a39c9b"><?php echo $ModFeatureStatus['Item']; ?></font> AIM - <font color ="#a39c9b"><?php echo $ModFeatureStatus['AIM']; ?></font> SilentAim - <font color ="#a39c9b"><?php echo $ModFeatureStatus['SilentAim']; ?></font> BulletTrack - <font color ="#a39c9b"><?php echo $ModFeatureStatus['BulletTrack']; ?></font> Memory - <font color ="#a39c9b"><?php echo $ModFeatureStatus['Memory']; ?></font> Floating Texts - <font color ="#a39c9b"><?php echo $ModFeatureStatus['Floating']; ?></font> Setting - <font color ="#a39c9b"><?php echo $ModFeatureStatus['Setting']; ?></font></label>
                        <label id="ESP" class="hacks">
                            ESP
                            <div class="switch">
                                <input type="checkbox" name="ESP" id="ESP" value="on" <?php if ($ModFeatureStatus['ESP'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <label id="Item" class="hacks">
                            Items
                            <div class="switch">
                                <input type="checkbox" name="Item" id="Item" value="on" <?php if ($ModFeatureStatus['Item'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <label id="AIM" class="hacks">
                            AIMBOT
                            <div class="switch">
                                <input type="checkbox" name="AIM" id="AIM" value="on" <?php if ($ModFeatureStatus['AIM'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <label id="SilentAim" class="hacks">
                            Silent Aim
                            <div class="switch">
                                <input type="checkbox" name="SilentAim" id="SilentAim" value="on" <?php if ($ModFeatureStatus['SilentAim'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <label id="BulletTrack" class="hacks">
                            BULLET-TRACK
                            <div class="switch">
                                <input type="checkbox" name="BulletTrack" id="BulletTrack" value="on" <?php if ($ModFeatureStatus['BulletTrack'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <label id="Memory" class="hacks">
                            Memory
                            <div class="switch">
                                <input type="checkbox" name="Memory" id="Memory" value="on" <?php if ($ModFeatureStatus['Memory'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <label id="Floating" class="hacks">
                            Floating Texts
                            <div class="switch">
                                <input type="checkbox" name="Floating" id="Floating" value="on" <?php if ($ModFeatureStatus['Floating'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <label id="Setting" class="hacks">
                            Settings
                            <div class="switch">
                                <input type="checkbox" name="Setting" id="Setting" value="on" <?php if ($ModFeatureStatus['Setting'] == "on"){?> checked="checked" <?php } ?>>
                                <span class="slider round"/>
                            </div>
                        </label>
                        <div class="form-group my-2">
                           <button type="submit" class="btn btn-outline-danger rounded-pill">
                                Update
                           </button>
                        </div>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
    
    <!----><!----><!----><!----><!----><!----><!----><!----><!----><!---->
    <div class="col-lg-6">
        <div class="card shadow h-10 py-2">
            <div class="card-header text-center font-weight-bold text-dark">
                Floating Text</div>
            <div class="card-body">
                <?= form_open() ?>
                    <input type="hidden" name="_ftext" value="1">
                    
                        <label for="status">
                            Current Mod Status: 
                            <font size="2" color ="#a39c9b">
                                <?php echo $userDetails2['_status']; ?>
                            </font>
                        </label>
                        <div class="input-group mb-3">
                            <label id="esp" class="hacks">
                                Safe Mode
                                    <div class="switch">
                                        <input type="checkbox" name="_ftextr" id="_ftextr" value="Safe" <?php if ($userDetails2['_status'] == "Safe"){?> checked="checked" <?php } ?>>
                                        <span class="slider round"/>
                                    </div>
                            </label>
                        </div>
                        <div class="form-group mb-3">
                            <label for="_ftext">Current Floating Text: <font size="2" color ="#a39c9b"><?php echo $userDetails2['_ftext']; ?></font></label>
                            <input type="text" name="_ftext" id="_ftext" class="form-control mt-2" placeholder="𝐺𝑖𝑣𝑒 𝐹𝑒𝑒𝑑𝑏𝑎𝑐𝑘 𝐸𝑠𝑒 𝐾𝑒𝑦 𝑅𝑒𝑜𝑣𝑒𝑑!" aria-describedby="help-_ftext" REQUIRED>
                            <?php if ($validation->hasError('_ftext')) : ?>
                                <small id="help-_ftext" class="text-danger"><?= $validation->getError('_ftext') ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="form-group my-2">
                            <button type="submit" class="btn btn-outline-success rounded-pill">Update</button>
                        </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>