<?php
$licenseKeyPath = __DIR__ . '/../license.key'; // Adjust the path as needed
$panel_id = '';

if (file_exists($licenseKeyPath)) {
    $panel_id = trim(file_get_contents($licenseKeyPath));
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Download</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-body text-center">
            <h3 class="mb-3">Latest Update</h3>
            <p><strong>Version:</strong> <span id="latest-version">Checking...</span></p>
            <p><strong>Changelog:</strong> <span id="changelog">-</span></p>
            <button id="download-btn" class="btn btn-primary">Download Update</button>
        </div>
    </div>
</div>

<script>
const encodedPanelId = "<?php echo htmlspecialchars($panel_id); ?>"; // Your panel_id

function disableCache(url) {
    return url + (url.includes('?') ? '&' : '?') + '_=' + new Date().getTime();
}

async function checkLatestVersion() {
    try {
        const res = await fetch('check_update.php');
        const data = await res.json();

        if (data.status === 'update_available') {
            document.getElementById('latest-version').textContent = data.latest_version;
            document.getElementById('changelog').textContent = data.changelog;
            document.getElementById('download-btn').onclick = () => logAndDownload(data.filename);
        } else {
            document.getElementById('latest-version').textContent = 'Up to date';
        }
    } catch (error) {
        console.error("Failed to fetch version info", error);
    }
}

async function logAndDownload(filename) {
    if (!encodedPanelId || !filename) {
        Swal.fire('Error', 'Missing download parameters.', 'error');
        return;
    }

    Swal.fire({
        title: 'Downloading...',
        html: '<b>Progress:</b> <span id="file-progress">0%</span>',
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
        }
    });

   try {
        const response = await fetch('save_update.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                panel_id: encodedPanelId,
                filename: filename
            })
        });

        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

        const data = await response.json();

        Swal.fire({
            title: data.status === 'success' ? 'Download Complete!' : 'Download Failed!',
            text: data.message,
            icon: data.status === 'success' ? 'success' : 'error'
        }).then(() => {
            if (data.status === 'success' && data.install_url) {
                window.location.href = data.install_url;
            } else {
                location.reload();
            }
        });

    } catch (err) {
        Swal.fire('Error', 'Download failed: ' + err.message, 'error').then(() => {
           location.reload(); //  Reload on error too
        });
    }
}

checkLatestVersion();
</script>

</body>
</html>
