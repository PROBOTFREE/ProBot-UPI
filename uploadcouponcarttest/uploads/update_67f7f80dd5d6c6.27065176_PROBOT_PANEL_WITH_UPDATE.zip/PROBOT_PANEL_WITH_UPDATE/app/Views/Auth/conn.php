<?php

$servername = "localhost";
$dbname = "probotfr_paid";
$username = "probotfr_paid";
$password = "4g{iAoxC1XlN";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>