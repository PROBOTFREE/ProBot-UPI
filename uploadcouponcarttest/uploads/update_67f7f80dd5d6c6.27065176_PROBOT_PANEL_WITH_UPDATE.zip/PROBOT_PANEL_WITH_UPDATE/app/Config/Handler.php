<?php
namespace Config;

class Handler {
    public static function getLicenseKey()
    {
        $licensePath = dirname(__DIR__, 2) . '/license.key';
        if (!file_exists($licensePath)) {
            return null;
        }
        return trim(file_get_contents($licensePath));
    }

    public static function validateLicense()
    {
        $license_key = self::getLicenseKey();
        if (!$license_key) {
            die("License key not found.");
        }

        $device_info = php_uname();
        $secret_key = 'YOUR_SECRET_SALT'; // Must match your backend
        $device_id = hash_hmac('sha256', $device_info, $secret_key);

        $payload = json_encode([
            'license_key' => $license_key,
            'device_id' => $device_id
        ]);

        $domain = $_SERVER['HTTP_HOST'];
        $headers = [
            'Content-Type: application/json',
            "X-Domain: $domain"
        ];

        $ch = curl_init('https://upload.couponcart.in/api/validate-license.php');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        $data = json_decode($response, true);

        if ($httpcode === 200 && isset($data['success']) && $data['success'] === true) {
            return true;
        }

        return false;
    }
}