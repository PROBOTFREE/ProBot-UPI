<?php
include('conn.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);

?>

<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<div class="row">
  <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
   <div class="col-lg-12">
        <div class="card shadow-lg p-0 mb-5 ">
                <div class="card-body text-dark h5">
                    <div class="row">
                        <div class="col pt-1">
                Add Money
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <div class="form-group mb-3">
                    <label for="set_saldo">You can add balance</label>
                    <div class="input-group mt-2">
                        <span class="input-group-text"><i class="bi bi-currency-rupee"></i></span>
                        <input type="number" class="form-control" name="set_saldo" id="set_saldo" minlength="1" maxlength="11" value="5">
                    </div>
                    <?php if ($validation->hasError('set_saldo')) : ?>
                        <small id="help-saldo" class="text-danger"><?= $validation->getError('set_saldo') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-outline-info rounded-pill">Add Now</button>
                </div>
                <?= form_close() ?>
            </div>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="card shadow h-100 py-2">
                <div class="card-header text-center font-weight-bold text-primary">
        Payment History
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-sm table-borderless table-hover text-center">
                <thead>
                    <tr>
                        <th>#ID</th>
                        <th>Order ID</th>
                        <th>User ID</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($history as $h) : ?>
                        <tr>
                            <td><span class="align-middle badge text-dark">#<?= $h->id ?></span></td>
                            <td><?= htmlspecialchars($h->order_id) ?></td>
                            <td><?= htmlspecialchars($h->user_id) ?></td>
                            <td><span class="align-middle badge text-dark">₹<?= number_format($h->amount, 2) ?></span></td>
                            <td>
                                <?php if ($h->status == 'SUCCESS') : ?>
                                    <span class="badge badge-success"><?= $h->status ?></span>
                                <?php elseif ($h->status == 'PENDING') : ?>
                                    <span class="badge badge-warning"><?= $h->status ?></span>
                                <?php else : ?>
                                    <span class="badge badge-danger"><?= $h->status ?></span>
                                <?php endif; ?>
                            </td>
                            <td><i class="align-middle badge text-muted"><?= $time::parse($h->created_at)->humanize() ?></i></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<br><br>
<?= $this->endSection() ?>