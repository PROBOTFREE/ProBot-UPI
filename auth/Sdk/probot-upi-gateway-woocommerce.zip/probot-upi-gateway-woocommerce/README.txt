=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://couponcart.in/
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Get Payment on your own UPI Gateway without any Transaction charges, Just a simple Subscriptions.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Goto WordPress Admin > Plugins > Add New > Upload the plugin zip file.

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.