<?php
error_reporting(0);
require_once('../include/connection.php');

// Set the timezone to Asia/Kolkata
date_default_timezone_set("Asia/Kolkata");


$amount=$_POST['amount'];
$senderNote=$_POST['remark1'];
$orderId=$_POST['order_id'];
$customerEmail="test@gmail.com";


        $updateQuery = "UPDATE tbl_wallet SET amount = amount + '$amount' WHERE userid = '$senderNote'";
        $updateResult = mysqli_query($con, $updateQuery);

        if ($updateResult) {
            echo "Amount updated successfully.";

            // Insert values into tbl_order
            $insertQuery = "INSERT INTO tbl_order (userid, transactionid, amount, status) VALUES ('".$senderNote."','".$orderId."','".$amount."','1')";
            $insertResult = mysqli_query($con, $insertQuery);

            if ($insertResult) {
                echo "Order details inserted successfully.";

                // Insert values into tbl_walletsummery
                $today = date("Y-m-d H:i:s");
                $walletSummaryQuery = "INSERT INTO tbl_walletsummery (userid, orderid, amount, type, actiontype, createdate) VALUES ('".$senderNote."','".$orderId."','".$amount."','credit','recharge','".$today."')";
                $walletSummaryResult = mysqli_query($con, $walletSummaryQuery);
                
                if ($walletSummaryResult) {
                    echo "Wallet summary details inserted successfully.";

                    // Insert values into deposits
                    $depositsQuery = "INSERT INTO deposits (status, uid, amount, ref_num, email, date) VALUES ('2', '".$senderNote."', '".$amount."', '".$orderId."', '".$customerEmail."', '".$today."')";
                    $depositsResult = mysqli_query($con, $depositsQuery);

                    if ($depositsResult) {
                        header("Location: /myaccount.php");
        exit;
                    } else {
                        echo "Error inserting deposit details: " . mysqli_error($con);
                    }
                } else {
                    echo "Error inserting wallet summary details: " . mysqli_error($con);
                }
            } else {
                echo "Error inserting order details: " . mysqli_error($con);
            }
        } else {
            echo "Error updating amount: " . mysqli_error($con);
        }
   

?>
