<?php
namespace App\Models;

use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table      = 'payments'; // Table name
    protected $primaryKey = 'id'; // Primary key

    protected $allowedFields = ['order_id', 'user_id', 'amount', 'status', 'created_at'];
    protected $useTimestamps = false; // No automatic timestamps

    // Function to get all payments (default 10 records, newest first)
    public function getAll($limit = 10, $orderBy = "DESC")
    {
        return $this->orderBy('id', $orderBy)
                    ->limit($limit)
                    ->get()
                    ->getResultObject();
    }

    // Function to get payments for a specific user
    public function getByUser($user_id, $limit = 10, $orderBy = "DESC")
    {
        return $this->where('user_id', $user_id)
                    ->orderBy('id', $orderBy)
                    ->limit($limit)
                    ->get()
                    ->getResultObject();
    }
}
