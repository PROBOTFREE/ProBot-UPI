<?php

include('conn.php');
include('mail.php');


?>
<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center pt-5">
    <div class="col-lg-6">
        <?= $this->include('Layout/msgStatus2') ?>
        
        <div class="card shadow-lg border-0 p-5" style="background: white; border-radius: 20px;">
            <div class="card-body text-center">
                <h2 class="fw-bold text-primary">Create an Account</h2>
                <p class="text-muted">Already have an account? <a href="<?= site_url('login') ?>" class="text-primary fw-bold">Sign in here</a></p>
            </div>
            <div class="card-body">
                <?= form_open() ?>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="username" class="fw-semibold text-dark">Username</label>
                        <input type="text" class="form-control mt-2 rounded p-3" name="username" id="username" placeholder="Your username" minlength="4" maxlength="24" value="<?= old('username') ?>" required>
                        <?php if ($validation->hasError('username')) : ?>
                        <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="fullname" class="fw-semibold text-dark">Mod Name</label>
                        <input type="text" class="form-control mt-2 rounded p-3" name="fullname" id="fullname" placeholder="Your mod name" minlength="4" maxlength="24" value="<?= old('fullname') ?>" required>
                        <?php if ($validation->hasError('fullname')) : ?>
                            <small class="text-danger"><?= $validation->getError('fullname') ?></small>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="form-group mb-3">
                    <label for="email" class="fw-semibold text-dark">E-Mail</label>
                    <input type="email" class="form-control mt-2 rounded p-3" name="email" id="email" placeholder="Enter your email" minlength="13" maxlength="40" value="<?= old('email') ?>" required>
                    <?php if ($validation->hasError('email')) : ?>
                        <small class="text-danger"><?= $validation->getError('email') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group mb-3">
                    <label for="password" class="fw-semibold text-dark">Password</label>
                    <input type="password" class="form-control mt-2 rounded p-3" name="password" id="password" placeholder="Enter your password" minlength="6" maxlength="24" required>
                    <?php if ($validation->hasError('password')) : ?>
                        <small class="text-danger"><?= $validation->getError('password') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group mb-3">
                    <label for="password2" class="fw-semibold text-dark">Confirm Password</label>
                    <input type="password" class="form-control mt-2 rounded p-3" name="password2" id="password2" placeholder="Confirm password" minlength="6" maxlength="24" required>
                    <?php if ($validation->hasError('password2')) : ?>
                        <small class="text-danger"><?= $validation->getError('password2') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-group mb-3">
                    <label for="referral" class="fw-semibold text-dark">Referral Code</label>
                    <input type="text" class="form-control mt-2 rounded p-3" name="referral" id="referral" placeholder="Referral code" maxlength="25" value="<?= old('referral') ?>" required>
                    <?php if ($validation->hasError('referral')) : ?>
                        <small class="text-danger"><?= $validation->getError('referral') ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="form-check mt-3 mb-4">
                    <input type="checkbox" class="form-check-input" id="terms-check">
                    <label class="form-check-label" for="terms-check">I agree to the <a href="#" class="text-primary">terms & conditions</a></label>
                </div>
                
                <div class="form-group d-grid">
                    <button type="submit" class="btn btn-primary rounded fw-semibold p-3 w-100">Sign Up</button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>