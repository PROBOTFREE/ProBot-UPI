<?php

$servername = "localhost";
$username = "gujjarpr_probotfree";
$password = "Ko47Gc@HGvEe";
$dbname = "gujjarpr_probotfree";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
  
?>